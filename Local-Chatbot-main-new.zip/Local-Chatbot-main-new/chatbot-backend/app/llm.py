# llm.py
import os
import json
import base64
import requests
from pathlib import Path
from typing import List, Dict, Optional, Union
from datetime import datetime
from PyPDF2 import PdfReader
import numpy as np
from langchain_community.embeddings import OllamaEmbeddings
from langchain_community.vectorstores import FAISS
from langchain_community.chat_models import ChatOllama
from langchain.schema import SystemMessage, HumanMessage, AIMessage
from app.chat_store import load_chat_messages

UPLOADS_DIR = os.path.abspath(os.path.join(os.path.dirname(__file__), "..", "uploads"))
VECTOR_STORE_PATH = Path("vector_store")
VECTOR_STORE_PATH.mkdir(exist_ok=True)

# Shared constants
EMBED_MODEL = "nomic-embed-text"
MULTIMODAL_MODEL = "llava"

TEXT_MODEL = "llama3.2"
SYSTEM_PROMPT = (
    "You are a helpful technical assistant. Use only the context provided from the uploaded files. "
    "Do not say 'I don't have enough information from the provided files to answer.' or something similar unless absolutely necessary. If you can say something based on the context, do so. "
)

# Initialize vector store
embedding = OllamaEmbeddings(model=EMBED_MODEL)
if (VECTOR_STORE_PATH / "index.faiss").exists():
    vectorstore = FAISS.load_local(
        str(VECTOR_STORE_PATH),
        embedding,
        index_name="index",
        allow_dangerous_deserialization=True
    )
else:
    # Delay initialization until there is data to ingest
    vectorstore = None

def is_image(meta) -> bool:
    return meta and meta.get("content_type", "").startswith("image/")

def get_file_path(meta) -> Optional[str]:
    if not meta or "stored_as" not in meta:
        return None
    return os.path.join(UPLOADS_DIR, meta["stored_as"])

def encode_image(path: str) -> str:
    print(f"[DEBUG] Encoding image at path: {path}")
    with open(path, "rb") as f:
        return base64.b64encode(f.read()).decode()

def ingest_pdf(file_path: str, chat_id: str):
    global vectorstore
    print(f"[DEBUG] Ingesting PDF: {file_path} for chat_id: {chat_id}")
    reader = PdfReader(file_path)
    all_chunks, metadata = [], []
    total_pages = len(reader.pages)
    print(f"[PROGRESS] PDF has {total_pages} pages. Starting chunking...")
    chunk_count = 0
    for i, page in enumerate(reader.pages):
        text = page.extract_text() or ""
        text = " ".join(text.split())
        if len(text) < 30:
            continue
        page_chunk_count = 0
        for j in range(0, len(text), 800):
            chunk = text[j:j+800]
            all_chunks.append(chunk)
            metadata.append({
                "source": f"{file_path}#page={i+1}",
                "chat_id": chat_id
            })
            chunk_count += 1
            page_chunk_count += 1
            print(f"[PROGRESS] Chunked page {i+1}/{total_pages}, chunk {page_chunk_count}")
    print(f"[DEBUG] Extracted {len(all_chunks)} chunks from PDF.")
    if all_chunks:
        if vectorstore is None:
            print("[DEBUG] Initializing new FAISS vectorstore with PDF chunks.")
            print(f"[PROGRESS] Embedding {len(all_chunks)} chunks...")
            vectorstore = FAISS.from_texts(all_chunks, embedding, metadatas=metadata)
            print(f"[PROGRESS] Embedded {len(all_chunks)} chunks.")
        else:
            print("[DEBUG] Adding PDF chunks to existing vectorstore.")
            print(f"[PROGRESS] Embedding {len(all_chunks)} new chunks...")
            for idx, chunk in enumerate(all_chunks):
                vectorstore.add_texts([chunk], metadatas=[metadata[idx]])
                if (idx + 1) % 5 == 0 or (idx + 1) == len(all_chunks):
                    print(f"[PROGRESS] Embedded {idx + 1}/{len(all_chunks)} chunks.")
        vectorstore.save_local(str(VECTOR_STORE_PATH), index_name="index")
        print("[DEBUG] Vectorstore saved after PDF ingestion.")

def ingest_image(file_path: str, user_prompt: str) -> str:
    print(f"[DEBUG] Ingesting image: {file_path} with user prompt: {user_prompt}")
    image_b64 = encode_image(file_path)
    response = requests.post(
        "http://localhost:11434/api/generate",
        json={
            "model": MULTIMODAL_MODEL,
            "prompt": user_prompt,
            "images": [image_b64],
            "stream": True
        },
        stream=True
    )
    result = ""
    print("[DEBUG] Streaming response from Ollama API:")
    for line in response.iter_lines():
        if line:
            try:
                chunk = json.loads(line.decode())
                content = chunk.get("response", "")
                print(content, end="", flush=True)
                result += content
            except Exception as e:
                print(f"[ERROR] Failed to parse streaming chunk: {e}")
    print()  # Newline after streaming
    print(f"[DEBUG] Image LLM response received: {result[:60]}...")
    return result

def retrieve_context(query: str, chat_id: str) -> str:
    print(f"[DEBUG] Retrieving context for query: '{query}' and chat_id: {chat_id}")
    if vectorstore is None:
        print("[DEBUG] No vectorstore available, returning empty context.")
        return ""
    docs = vectorstore.similarity_search(query, k=5)
    print(f"[DEBUG] Retrieved {len(docs)} documents from vectorstore.")
    return "\n\n".join(d.page_content for d in docs if d.metadata.get("chat_id") == chat_id)

def generate_llm_response(prompt: str, model_id: str, username: str, chat_id: str, attachment_meta=None) -> dict:
    try:
        print(f"[DEBUG] generate_llm_response called with prompt: '{prompt}', model_id: {model_id}, username: {username}, chat_id: {chat_id}")
        file_path = get_file_path(attachment_meta)
        use_multimodal = False
        if file_path:
            print(f"[DEBUG] Attachment detected: {file_path}")
            if is_image(attachment_meta):
                print("[DEBUG] Attachment is an image.")
                # Directly send image and prompt to Ollama API, return response
                text = ingest_image(file_path, prompt)
                if not text or len(text) < 3:
                    text = "I don't have enough information from the provided files to answer."
                return {"text": text, "image": None}
            elif file_path.lower().endswith(".pdf"):
                print("[DEBUG] Attachment is a PDF.")
                ingest_pdf(file_path, chat_id)
        else:
            print("[DEBUG] No attachment provided.")

        # Prepare conversation history for /chat/ endpoint
        all_messages = load_chat_messages(username, chat_id)
        print(f"[DEBUG] Loaded {len(all_messages)} chat messages for history.")
        history = []
        for msg in all_messages[-6:]:
            if msg["sender"] == "user":
                history.append(HumanMessage(content=msg["text"]))
            elif msg["sender"] == "bot":
                history.append(AIMessage(content=msg["text"]))

        # Context from RAG (PDF/image)
        context = retrieve_context(prompt, chat_id)
        print(f"[DEBUG] Context for prompt: {context[:100]}...")

        # Make the prompt more explicit if image is attached
        if use_multimodal:
            explicit_prompt = (
                f"{SYSTEM_PROMPT}\n\n"
                f"Context (this is a description of the provided image):\n{context}\n\n"
                f"User: {prompt}\n"
                f"Please answer based only on the image description above."
            )
        else:
            explicit_prompt = f"{SYSTEM_PROMPT}\n\nContext:\n{context}\n\nUser: {prompt}"

        # Use vision model if image is attached, otherwise use text model
        selected_model = MULTIMODAL_MODEL if use_multimodal else TEXT_MODEL
        chat = ChatOllama(model=selected_model)
        print(f"[DEBUG] ChatOllama model initialized: {chat.model}")

        messages = [SystemMessage(content=SYSTEM_PROMPT)] + history + [HumanMessage(content=explicit_prompt)]
        print(f"[DEBUG] Sending {len(messages)} messages to LLM.")
        response = chat(messages)
        text = response.content.strip()
        print(f"[DEBUG] LLM response: {text[:100]}...")

        if "I don't know" in text or not text or len(text) < 3:
            text = "I don't have enough information from the provided files to answer."
            print("[DEBUG] LLM response insufficient, using fallback message.")

        return {"text": text, "image": None}
    except Exception as e:
        print(f"[ERROR] LLM response generation failed: {e}")
        return {"text": "Unable to get response", "image": None}
